from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton


def main_menu():
    kb = InlineKeyboardMarkup(row_width=2)

    kb.add(
        InlineKeyboardButton("🛠 Создать систему", callback_data="create_system"),
        InlineKeyboardButton("🐞 Исправить ошибку", callback_data="fix_error")
    )

    kb.add(
        InlineKeyboardButton("📂 Мои проекты", callback_data="projects"),
        InlineKeyboardButton("📄 Проверить .pwn", callback_data="check_pwn")
    )

    kb.add(
        InlineKeyboardButton("⚙️ Админ панель", callback_data="admin_panel")
    )

    return kb


def create_system_menu():
    kb = InlineKeyboardMarkup(row_width=2)

    kb.add(
        InlineKeyboardButton("💬 Диалоги", callback_data="dialog"),
        InlineKeyboardButton("🖥 GUI", callback_data="gui")
    )

    kb.add(
        InlineKeyboardButton("⌨️ Команды", callback_data="commands"),
        InlineKeyboardButton("🎨 TextDraw", callback_data="textdraw")
    )

    kb.add(
        InlineKeyboardButton("🚗 Система", callback_data="system"),
        InlineKeyboardButton("🗄 MySQL", callback_data="mysql")
    )

    kb.add(
        InlineKeyboardButton("📝 По описанию", callback_data="description")
    )

    kb.add(
        InlineKeyboardButton("🔙 Назад", callback_data="back")
    )

    return kb