from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton


def admin_menu():
    kb = InlineKeyboardMarkup(row_width=2)

    kb.add(
        InlineKeyboardButton("👥 Пользователи", callback_data="admin_users"),
        InlineKeyboardButton("🧠 Генерации", callback_data="admin_generations")
    )

    kb.add(
        InlineKeyboardButton("📂 Проекты", callback_data="admin_projects"),
        InlineKeyboardButton("📜 Логи", callback_data="admin_logs")
    )

    kb.add(
        InlineKeyboardButton("📊 Статистика", callback_data="admin_stats"),
        InlineKeyboardButton("🚫 Блокировки", callback_data="admin_bans")
    )

    kb.add(
        InlineKeyboardButton("⚙️ Настройки", callback_data="admin_settings")
    )

    kb.add(
        InlineKeyboardButton("🔙 Назад", callback_data="back_main")
    )

    return kb