from openai import OpenAI
from config import OPENAI_API_KEY


client = OpenAI(
    api_key=OPENAI_API_KEY
)


def generate_code(description, category):

    prompt = f"""
Ты профессиональный разработчик CRMP/SA-MP.

Твоя задача — создавать готовый Pawn код.

Категория:
{category}

Описание пользователя:
{description}

Правила:
- Пиши полный код.
- Используй Pawn.
- Учитывай CRMP/SA-MP.
- Если нужны команды — создавай команды.
- Если нужен MySQL — добавляй таблицы и запросы.
- Объясняй куда вставлять код.
- Не пиши лишнюю информацию.
"""

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {
                "role": "system",
                "content": "Ты CRMP разработчик."
            },
            {
                "role": "user",
                "content": prompt
            }
        ]
    )

    return response.choices[0].message.content