import telebot

from config import BOT_TOKEN
from database import create_tables

from handlers import menu
from handlers import admin
from handlers import generator
from handlers import fixer
from handlers import projects


bot = telebot.TeleBot(BOT_TOKEN)


create_tables()


menu.register_handlers(bot)
admin.register_handlers(bot)
generator.register_handlers(bot)
fixer.register_handlers(bot)
projects.register_handlers(bot)


@bot.message_handler(commands=["start"])
def start(message):

    from keyboards.main import main_menu

    bot.send_message(
        message.chat.id,
        "🤖 CRMP AI Studio\n\n"
        "Создание CRMP/SA-MP систем через ИИ.",
        reply_markup=main_menu()
    )


print("CRMP AI запущен")

bot.infinity_polling()