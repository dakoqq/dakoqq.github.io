import sqlite3
import os


os.makedirs("database", exist_ok=True)

DB = "database/users.db"


def connect():
    return sqlite3.connect(DB)


def create_tables():
    db = connect()
    cursor = db.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT,
        generations INTEGER DEFAULT 0,
        projects INTEGER DEFAULT 0
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS generations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        request TEXT,
        category TEXT,
        date TEXT
    )
    """)

    db.commit()
    db.close()


def add_user(user_id, username):
    db = connect()
    cursor = db.cursor()

    cursor.execute(
        "INSERT OR IGNORE INTO users (id, username) VALUES (?, ?)",
        (user_id, username)
    )

    db.commit()
    db.close()


def add_generation(user_id, request, category):
    db = connect()
    cursor = db.cursor()

    cursor.execute(
        """
        INSERT INTO generations
        (user_id, request, category, date)
        VALUES (?, ?, ?, datetime('now'))
        """,
        (user_id, request, category)
    )

    cursor.execute(
        """
        UPDATE users 
        SET generations = generations + 1
        WHERE id = ?
        """,
        (user_id,)
    )

    db.commit()
    db.close()