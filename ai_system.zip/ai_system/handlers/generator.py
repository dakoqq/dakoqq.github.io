from telebot.types import CallbackQuery
from ai import generate_code
from database import add_generation
import os


user_states = {}


def register_handlers(bot):

    @bot.callback_query_handler(func=lambda call: call.data in [
        "dialog",
        "gui",
        "commands",
        "textdraw",
        "system",
        "mysql",
        "description"
    ])
    def generator_menu(call: CallbackQuery):

        categories = {
            "dialog": "💬 Диалоги",
            "gui": "🖥 GUI",
            "commands": "⌨️ Команды",
            "textdraw": "🎨 TextDraw",
            "system": "🚗 Система",
            "mysql": "🗄 MySQL",
            "description": "📝 По описанию"
        }

        user_states[call.from_user.id] = categories[call.data]

        bot.edit_message_text(
            f"{categories[call.data]}\n\n"
            "📝 Опишите, что нужно создать.\n\n"
            "Пример:\n"
            "Создай систему семьи с GUI, рангами и MySQL.",
            call.message.chat.id,
            call.message.message_id
        )


    @bot.message_handler(
        func=lambda message: message.from_user.id in user_states
    )
    def generate(message):

        category = user_states[message.from_user.id]

        description = message.text

        bot.send_message(
            message.chat.id,
            "🤖 Генерирую систему...\n\n"
            "⏳ Подождите..."
        )


        try:

            code = generate_code(
                description,
                category
            )


            add_generation(
                message.from_user.id,
                description,
                category
            )


            os.makedirs(
                f"storage/projects/{message.from_user.id}",
                exist_ok=True
            )


            file_path = (
                f"storage/projects/"
                f"{message.from_user.id}/"
                f"generation.txt"
            )


            with open(
                file_path,
                "w",
                encoding="utf-8"
            ) as file:
                file.write(code)


            bot.send_message(
                message.chat.id,
                "✅ Система создана!\n\n"
                f"📂 Категория: {category}\n\n"
                f"{code}"
            )


            bot.send_document(
                message.chat.id,
                open(file_path, "rb"),
                caption="📄 Файл проекта"
            )


        except Exception as error:

            bot.send_message(
                message.chat.id,
                f"❌ Ошибка генерации:\n{error}"
            )


        del user_states[message.from_user.id]