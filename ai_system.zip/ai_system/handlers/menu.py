from telebot.types import CallbackQuery
from keyboards.main import main_menu, create_system_menu
from keyboards.admin import admin_menu
from config import ADMIN_ID


def register_handlers(bot):

    @bot.callback_query_handler(func=lambda call: call.data == "create_system")
    def create_system(call: CallbackQuery):
        bot.edit_message_text(
            "🛠 Выберите, что хотите создать:",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=create_system_menu()
        )

    @bot.callback_query_handler(func=lambda call: call.data == "back")
    def back(call: CallbackQuery):
        bot.edit_message_text(
            "🏠 Главное меню",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=main_menu()
        )

    @bot.callback_query_handler(func=lambda call: call.data == "admin_panel")
    def admin_panel(call: CallbackQuery):
        if call.from_user.id != ADMIN_ID:
            bot.answer_callback_query(
                call.id,
                "❌ У вас нет доступа.",
                show_alert=True
            )
            return

        bot.edit_message_text(
            "⚙️ Админ панель",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=admin_menu()
        )

    @bot.callback_query_handler(func=lambda call: call.data == "back_main")
    def back_main(call: CallbackQuery):
        bot.edit_message_text(
            "🏠 Главное меню",
            call.message.chat.id,
            call.message.message_id,
            reply_markup=main_menu()
        )