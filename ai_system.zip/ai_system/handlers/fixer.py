from telebot.types import CallbackQuery

fix_states = {}


def register_handlers(bot):

    @bot.callback_query_handler(func=lambda call: call.data == "fix_error")
    def fix_error(call: CallbackQuery):

        fix_states[call.from_user.id] = True

        bot.edit_message_text(
            "🐞 Исправление ошибки\n\n"
            "Отправьте ошибку компиляции или код, который нужно исправить.\n\n"
            "Пример:\n"
            "error 017: undefined symbol PlayerInfo",
            call.message.chat.id,
            call.message.message_id
        )


    @bot.message_handler(func=lambda message: message.from_user.id in fix_states)
    def process_fix(message):

        error = message.text

        bot.send_message(
            message.chat.id,
            "🔍 Анализирую ошибку...\n\n"
            f"Ошибка:\n{error}\n\n"
            "🤖 Исправление будет создано ИИ."
        )

        del fix_states[message.from_user.id]