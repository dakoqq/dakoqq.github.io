from telebot.types import CallbackQuery
from config import ADMIN_ID


def register_handlers(bot):

    @bot.callback_query_handler(func=lambda call: call.data.startswith("admin_"))
    def admin_callbacks(call: CallbackQuery):

        if call.from_user.id != ADMIN_ID:
            bot.answer_callback_query(
                call.id,
                "❌ У вас нет доступа.",
                show_alert=True
            )
            return

        if call.data == "admin_users":
            bot.edit_message_text(
                "👥 Пользователи\n\n"
                "Здесь будет список всех пользователей.",
                call.message.chat.id,
                call.message.message_id
            )

        elif call.data == "admin_generations":
            bot.edit_message_text(
                "🧠 Генерации\n\n"
                "Здесь будут отображаться последние запросы к ИИ.",
                call.message.chat.id,
                call.message.message_id
            )

        elif call.data == "admin_projects":
            bot.edit_message_text(
                "📂 Проекты\n\n"
                "Здесь будут отображаться проекты пользователей.",
                call.message.chat.id,
                call.message.message_id
            )

        elif call.data == "admin_logs":
            bot.edit_message_text(
                "📜 Логи\n\n"
                "Здесь будут отображаться последние действия бота.",
                call.message.chat.id,
                call.message.message_id
            )

        elif call.data == "admin_stats":
            bot.edit_message_text(
                "📊 Статистика\n\n"
                "Здесь будет общая статистика бота.",
                call.message.chat.id,
                call.message.message_id
            )

        elif call.data == "admin_bans":
            bot.edit_message_text(
                "🚫 Блокировки\n\n"
                "Здесь можно управлять заблокированными пользователями.",
                call.message.chat.id,
                call.message.message_id
            )

        elif call.data == "admin_settings":
            bot.edit_message_text(
                "⚙️ Настройки\n\n"
                "Здесь будут настройки бота и ИИ.",
                call.message.chat.id,
                call.message.message_id
            )