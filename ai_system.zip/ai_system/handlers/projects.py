from telebot.types import CallbackQuery
import os


def register_handlers(bot):

    @bot.callback_query_handler(func=lambda call: call.data == "projects")
    def show_projects(call: CallbackQuery):

        path = f"storage/projects/{call.from_user.id}"

        if not os.path.exists(path):
            bot.edit_message_text(
                "📂 У вас нет проектов.",
                call.message.chat.id,
                call.message.message_id
            )
            return


        files = os.listdir(path)

        text = "📂 Ваши проекты:\n\n"

        for file in files:
            text += f"📄 {file}\n"


        bot.edit_message_text(
            text,
            call.message.chat.id,
            call.message.message_id
        )